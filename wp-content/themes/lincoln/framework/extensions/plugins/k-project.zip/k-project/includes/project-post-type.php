<?php
// Register custom post type "Page Section"
add_action('init', 'k2t_register_project', 0); 
function k2t_register_project()  { 
  global $smof_data;
  $project_slug = $smof_data['project-slug'];
  
  $labels = array(  
    'name' => __('K-Project', 'k2t-project'),  
    'singular_name' => __('All Project', 'k2t-project'),  
    'add_new' => __('Add New project', 'k2t-project'),  
    'add_new_item' => __('Add New project', 'k2t-project'),  
    'edit_item' => __('Edit project', 'k2t-project'),  
    'new_item' => __('New project', 'k2t-project'),  
    'view_item' => __('View project', 'k2t-project'),  
    'search_items' => __('Search project', 'k2t-project'),  
    'not_found' =>  __('No project found', 'k2t-project'),  
    'not_found_in_trash' => __('No project found in Trash', 'k2t-project'),  
    'parent_item_colon' => '' 
  );  
  
  $args = array(  
    'labels' 				=> $labels,  
    'menu_position' 		=> 5, 
	'public' 				=> true,
	'publicly_queryable' 	=> true,
	'has_archive' 			=> true,
	'hierarchical' 			=> false,
	'supports' 				=> array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
  );
  if(!empty($project_slug)){
  	$args['rewrite'] = array('slug' => $project_slug);
  }else{
	$args['rewrite'] = array('slug' => 'project');
  }
  register_post_type('post-k-project',$args);
}

/* --------------------------------------------------- */
/* Register project Category
/* --------------------------------------------------- */
add_action( 'init', 'k2t_register_project_category', 0 );

if ( !function_exists('k2t_register_project_category') ) {
function k2t_register_project_category(){
	global $smof_data;
  	$project_category_slug = $smof_data['project-category-slug'];
	$labels = array(
		'name'                => _x( 'Project Categories', 'taxonomy general name','k2t-project'),
		'singular_name'       => _x( 'Project Category', 'taxonomy singular name','k2t-project'),
		'search_items'        => __( 'Search Project Categories','k2t-project'),
		'all_items'           => __( 'All Project Categories','k2t-project'),
		'parent_item'         => __( 'Parent Project Category','k2t-project'),
		'parent_item_colon'   => __( 'Parent Project Category:','k2t-project'),
		'edit_item'           => __( 'Edit Project Category','k2t-project'), 
		'update_item'         => __( 'Update Project Category','k2t-project'),
		'add_new_item'        => __( 'Add New Project Category','k2t-project'),
		'new_item_name'       => __( 'New Project Category Name','k2t-project'),
		'menu_name'           => __( 'Project Category','k2t-project')
	);
	
	$args = array(
		'hierarchical'        => true,
		'labels'              => $labels,
		'show_ui'             => true,
		'show_admin_column'   => true,
		'query_var'           => true,
	);
	
	if(!empty($project_category_slug)){
		$args['rewrite'] = array('slug' => $project_category_slug);
	}else{
		$args['rewrite'] = array('slug' => 'project-k-category');
	}
	
	register_taxonomy( 'k-project-category', array('post-k-project'), $args );

	$labels = array(
		'name'                => _x( 'Project Tags', 'taxonomy general name','k2t-project'),
		'singular_name'       => _x( 'Project Tag', 'taxonomy singular name','k2t-project'),
		'search_items'        => __( 'Search Project Tags','k2t-project'),
		'all_items'           => __( 'All Project Tags','k2t-project'),
		'parent_item'         => __( 'Parent Project Tag','k2t-project'),
		'parent_item_colon'   => __( 'Parent Project Tag:','k2t-project'),
		'edit_item'           => __( 'Edit Project Tag','k2t-project'), 
		'update_item'         => __( 'Update Project Tag','k2t-project'),
		'add_new_item'        => __( 'Add New Project Tag','k2t-project'),
		'new_item_name'       => __( 'New Project Tag Name','k2t-project'),
		'menu_name'           => __( 'Project Tag','k2t-project')
	);
	
	$args = array(
		'hierarchical'        => true,
		'labels'              => $labels,
		'show_ui'             => true,
		'show_admin_column'   => true,
		'query_var'           => true,
		'rewrite'			  => array('slug' => 'project-k-tag'),
	);
	// $args['rewrite'] = array('slug' => 'project-k-tag');
	
	register_taxonomy( 'k-project-tag', array('post-k-project'), $args );
}

}

?>