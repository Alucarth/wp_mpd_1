<?php
/*
Plugin Name: Import Demo Data
Description: This is the plugin for 1 click install demo data.
Version: 1.0.0
Text domain: z-import-demo
*/

function z_import_filter_fw_ext_backups_demos($demos) {

	$template = get_option('template');

	$theme = wp_get_theme();

	$link = 'http://host.' . $theme->display( 'Author', FALSE )  . '.com/' . $template . '/';

    $demos_array = array(
					'full' => array(
					    'title' 		 => esc_html__('Demo Full Data', 'z-import-demo'),
					    'screenshot'	 => $link . 'screenshot.jpg',
					    'preview_link' 	 => $theme->get('ThemeURI') ,
					),
        // ...
    );

    $download_url = esc_url( $link );

    foreach ($demos_array as $id => $data) {
        $demo = new FW_Ext_Backups_Demo($id, 'piecemeal', array(
            'url' => $download_url,
            'file_id' => $id,
        ));
        $demo->set_title($data['title']);
        $demo->set_screenshot($data['screenshot']);
        $demo->set_preview_link($data['preview_link']);

        $demos[ $demo->get_id() ] = $demo;

        unset($demo);
    }

    return $demos;
}

add_filter('fw:ext:backups-demo:demos', 'z_import_filter_fw_ext_backups_demos');

add_action( 'admin_menu', 'my_admin_menu' );

function my_admin_menu() {
	add_submenu_page( 'tools.php', '1 click Install', 'Import Demo Data', 'manage_options', 'z-1-click', 'z_1_click_import_demo_data' ); 
}
function z_1_click_import_demo_data() {

	$template = get_option('template');

	$theme = wp_get_theme();

	$link = 'http://host.' . $theme->display( 'Author', FALSE ) . '.com/' . $template . '/';

	echo '<h1> Import Demo data for : ' . strtoupper( $template ) . '</h1>';

	$install_nonce    = wp_create_nonce( 'tgmpa-install' );
	$activate_nonce   = wp_create_nonce( 'tgmpa-activate' );
	$extensions_nonce = wp_create_nonce( 'install' );
	$pl = array(
		'name'
		);
	?>

	<div class="wrapper" style="margin-top: 30px">
		<h2 style="color: red"> Warning: This will import delete current database and import our demo content. </h2>
		<a href="<?php echo $theme->get('ThemeURI');?>">
			<img src="<?php echo( $link . 'screenshot.jpg' );?>" style="max-width: 400px;" />
		</a>
		</br>
		<button class="z-install button button-primary" style="margin-top: 30px; float: left;" 
			data-install="<?php echo esc_attr( $install_nonce ); ?>" 
			data-active="<?php echo $activate_nonce;?>" 
			data-extension="<?php echo $extensions_nonce;?>" 
			data-source="<?php echo plugin_dir_path( __FILE__ ) . 'plugins/unyson.zip';?>" 
		> Import Demo Data </button><span class="install-now button" style="float: left; margin-top: 30px;background: transparent;border: none;box-shadow: none;"></span>
		<span style="float:left; margin-top: 35px; font-weight:bold;opacity: 0"> Please Be Patience!</span>
		<style>.updating-message ~ span { opacity: 1 !important; }</style>
	</div>

	<?php
}

add_action( 'admin_enqueue_scripts', 'z_1_click_enqueue_script' );
function z_1_click_enqueue_script() {
	if ( isset(  $_GET['page']  )  &&  in_array( $_GET['page'], array( 'z-1-click', 'fw-backups-demo-content' ) ) ) {
		wp_enqueue_script( 'z-1-click', plugins_url() . '/z-import-demo/js/script.js', array( 'jquery' ), '1.0.0', true );
	}
}

function z_import_data_register_tgmpa() {

	if( isset(  $_GET['page']  )  &&  in_array( $_GET['page'], array( 'z-1-click', 'fw-backups-demo-content' ) ) || ( isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') ) :

		$plugins = array(
			array(
				'name'           => esc_html__( 'Unyson','kids' ),
				'slug'           => 'unyson',
				'required'       => true,
				'file'	         => 'unyson.php',
				'source'		 => plugin_dir_path( __FILE__ ) . 'plugins/unyson.zip',
			)
		);

		tgmpa( $plugins );

	endif;

}

add_action( 'tgmpa_register', 'z_import_data_register_tgmpa', 999 );

function _filter_plugin_awesome_extensions($locations) {
    $locations[ dirname(__FILE__) . '/extensions' ]
    =
    plugin_dir_url( __FILE__ ) . 'extensions';

    return $locations;
}
add_filter('fw_extensions_locations', '_filter_plugin_awesome_extensions');

function z_import_detect_plugin_activation( $plugin ) {
    if( $plugin == plugin_basename( __FILE__ ) ) {
        exit( wp_redirect( admin_url( 'tools.php?page=z-1-click' ) ) );
    }
}
add_action( 'activated_plugin', 'z_import_detect_plugin_activation', 10, 2 );
