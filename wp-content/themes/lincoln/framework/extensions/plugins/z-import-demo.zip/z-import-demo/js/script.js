

jQuery(document).ready(function(){
	var $ = jQuery;

	$('.z-install').on('click',function(){

		console.log('Import demo data');

		var pl  = {
			name: 'unyson', 
			slug: 'unyson',
			install_nonce: $('.z-install').attr('data-install'),
			activate_nonce: $('.z-install').attr('data-active'),
			extension: $('.z-install').attr('data-extension'),
			source: $('.z-install').attr('data-source'),
		};

		$(this).next().addClass('updating-message');

		ajax_tgmpa_install( pl );

	});


	function ajax_tgmpa_install( pl ){
		var plugin_source_temp = ( pl['source'] != '' ) ? "&plugin_source=" +  pl['source'] : "&plugin_source=repo" ;
		$.ajax({
			async: true,
			url: home_url + '/wp-admin/themes.php?page=tgmpa-install-plugins&plugin=' + pl["slug"] + '&plugin_name=' + pl["name"].replace(" ", "%20")  + plugin_source_temp + '&tgmpa-install=install-plugin&tgmpa-nonce=' + pl["install_nonce"],
			complete: function( data ) {
				$.ajax({
					async: true,
					url: home_url + '/wp-admin/themes.php?page=tgmpa-install-plugins&plugin=' + pl["slug"] + '&plugin_name=' + pl["name"].replace(" ", "%20") + plugin_source_temp + '&tgmpa-activate=activate-plugin&tgmpa-nonce=' + pl["activate_nonce"],
					complete: function( data ) {
						$.ajax({
							async: true,
							url: home_url + '/wp-admin/themes.php?page=tgmpa-install-plugins&tgmpa-nonce=' + pl["install_nonce"],
							complete: function (data) {
								console.log('complete 1')
								if( pl["slug"] === 'unyson' ) {
									$.ajax({
										type: "POST",
										url: home_url + '/wp-admin/admin.php?page=fw-extensions&sub-page=install&extension=backups',
										data: "_nonce_fw_extensions_install="+pl["extension"],
										complete: function (data) {
											console.log( 'complete unyson' );

											$.ajax({
												url: ajaxurl,
												type: 'POST',
												data: {
													action: 'fw:ext:backups-demo:install',
													id: 'full',
												},
												success: function(response) {
													console.log( response );
													if ( typeof response['data'] !== 'undefined' || ( typeof response['success'] !== 'undefined' && response['success'] == true )  ) {
														window.location = home_url + '/wp-admin/tools.php?page=fw-backups-demo-content';
													} 
												},
												error: function(err) {
													console.log( err )
												}
											});
										}
									});
								} 
							}
						});
					}
				});
			}
		});
	}
});