<?php
/**
 * The template for displaying Category pages
 */
get_header();


// Register variables
global $smof_data;

$pre 	= 'teacher-category-';

$stt = array( 
	'style'          => 'style-shadow-box',
	'layout'         => 'right_sidebar',
	'columns'        => 'columns-3',
	'excerpt'        => 'show',
	'excerpt-length' => '15',
);

if ( isset( $smof_data['teacher-category-layout'] ) ) {
	foreach ($stt as $key => $value) {
		$stt[ $key ] = $smof_data[ $pre . $key ];
	}
}

// Layout of single course
$classes[] = str_replace( '_', '-', $stt['layout'] );

// Get current term
$term = get_queried_object()->term_taxonomy_id;

?>
<div class="k2t-content <?php echo esc_attr( implode( ' ', $classes ) ) ?>" style="<?php echo esc_attr( implode( ' ', $style_attr ) ) ?>">

	<div class="container k2t-wrap">

		<!-- Main -->
		<main class="k2t-main page" role="main">
			<?php 
				echo k_teacher_listing_shortcode( 
					array(
						'style' 				=> $stt['style'],
						'column' 		        => $stt['columns'],
						'teacher_per_page'      => '-1',
						'excerpt'		        => $stt['excerpt'],
						'excerpt_length'		=> $stt['excerpt-length'],
						'cat'					=> $term,
					)
				);
			 ?>
		</main>

		<!-- Sidebar -->
		<?php
			if ( 'right_sidebar' == $stt['layout'] || 'left_sidebar' == $stt['layout'] ) {
				get_sidebar();
			}
		?>
	</div>

</div>
<?php get_footer(); ?>