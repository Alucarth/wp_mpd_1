<?php

add_action( 'init', 'k2t_teacher_regsiter_ct', 0 );

function k2t_teacher_regsiter_ct() {
	$slug = ( get_option( 'k2t_teacher_slug' ) != '' ) ?  get_option( 'k2t_teacher_slug' ) : esc_html__( 'k-Teacher', 'k2t-teacher' );
	$slug_cat = ( get_option( 'k2t_tag_category_slug' ) != '' ) ?  get_option( 'k2t_tag_category_slug' ) : esc_html__( 'k-tag-category', 'k2t-teacher' );

	$labels = array(
		'name'               => __('K-Teacher', 'k2t-teacher'),  
		'singular_name'      => __('K-Teacher', 'k2t-teacher'),  
		'add_new'            => __('Add New Teacher', 'k2t-teacher'),  
		'add_new_item'       => __('Add New Teacher', 'k2t-teacher'),  
		'edit_item'          => __('Edit Teacher', 'k2t-teacher'),  
		'new_item'           => __('New Teacher', 'k2t-teacher'),  
		'view_item'          => __('View Teacher', 'k2t-teacher'),  
		'all_items'          => __('All Teachers', 'k2t-teacher'),
		'search_items'       => __('Search Teacher', 'k2t-teacher'),  
		'not_found'          =>  __('No Teacher found', 'k2t-teacher'),  
		'not_found_in_trash' => __('No Teacher found in Trash', 'k2t-teacher'),  
		'parent_item_colon'  => ''
	);
	$args = array (
		'labels'             => $labels,
        'description'        => __( 'Description.', 'k2t-teacher' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
		'rewrite' 			 => array( 'slug' => $slug, 'with_front' => FALSE )
	);

	register_post_type( 'post-k-teacher' , $args );

	// TEACHER CATEGORY

	$args = array(
		'labels' => array(
			'name'                => __( 'Teacher Categories', 'taxonomy general name','k2t-teacher'),
			'singular_name'       => __( 'K-Teacher Category', 'taxonomy singular name','k2t-teacher'),
			'search_items'        => __( 'Search K-Teacher Categories','k2t-teacher'),
			'all_items'           => __( 'All K-Teacher Categories','k2t-teacher'),
			'parent_item'         => __( 'Parent K-Teacher Category','k2t-teacher'),
			'parent_item_colon'   => __( 'Parent K-Teacher Category:','k2t-teacher'),
			'edit_item'           => __( 'Edit K-Teacher Category','k2t-teacher'), 
			'update_item'         => __( 'Update K-Teacher Category','k2t-teacher'),
			'add_new_item'        => __( 'Add New K-Teacher Category','k2t-teacher'),
			'new_item_name'       => __( 'New K-Teacher Category Name','k2t-teacher'),
			'menu_name'           => __( 'K-Teacher Categories','k2t-teacher')
		),
		'rewrite' => array('slug' => $slug_cat ),
	);

	register_taxonomy( 'k-teacher-category', 'post-k-teacher' , $args );
}
