/* jQuery DOM Teachers */

jQuery(document).ready(function($){
	$('a.teacher-featured').on('click', function(){
		var id = $(this).attr('data-id'),
			value = 0;
			$loader = $(this).next()

		$loader.addClass('updating-message');

		if ( $(this).hasClass('zmdi-star') ) {
			$(this).removeClass('zmdi-star').addClass('zmdi-star-outline');
		} else {
			value = 1;
			$(this).removeClass('zmdi-star-outline').addClass('zmdi-star');
		}

		$.ajax({
			url: ajaxurl,
			type: "POST",
			data: {
				action  : 'k2t_teacher_featured',
				id      : id,
				featured: value,
			},
			success: function( response ) {
				$loader.removeClass('updating-message');
			},
			error: function(errorThrown){
			    console.log( errorThrown );
			}
		});

		return false;
	});
});

