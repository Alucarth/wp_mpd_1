<?php

if( !function_exists('k_teacher_listing_shortcode') ){
	function k_teacher_listing_shortcode($atts, $content = null){
		extract( shortcode_atts( array(
			'style' 				=> 'style-classic',
			'enable_slider' 		=> 'no',
			'column_desktop'		=> '4',
			'column_tablet'			=> '2',
			'column_mobile'			=> '1',
			'navigation'			=> 'show',
			'column' 		        => '4',
			'teacher_per_page'      => '12',
			'excerpt'		        => 'show',
			'excerpt_length'		=> '15',
			'cat'					=> '',
			'filter_bar'			=> '',
		), $atts));


		// include( plugin_dir_path( __FILE__ ) . '../class.k_teacher.php' );
		if ( $enable_slider != 'yes' )  {

			$html = k2t_get_template_part('teacher', 'listing', array(
	            'style' 				=> $style,
	            'column' 		        => $column,
	            'teacher_per_page'      => $teacher_per_page,
	            'excerpt'		        => $excerpt,
	            'excerpt_length'		=> $excerpt_length,
				'cat'					=> $cat,
				'filter_bar'			=> $filter_bar,
	            )
	        );
        } else {
        	$html = k2t_get_template_part('teacher', 'slider', array(
	            'style' 				=> $style,
	            'enable_slider' 		=> $enable_slider,
				'column_desktop'		=> $column_desktop,
				'column_tablet'			=> $column_tablet,
				'column_mobile'			=> $column_mobile,
				'navigation'			=> 'show',
	            'teacher_per_page'      => $teacher_per_page,
	            'excerpt'		        => $excerpt,
	            'excerpt_length'		=> $excerpt_length,
				'cat'					=> $cat,
	            )
	        );
        }

		wp_reset_postdata();

		return $html;
	}
	
	add_shortcode('k_teacher_listing', 'k_teacher_listing_shortcode');
}