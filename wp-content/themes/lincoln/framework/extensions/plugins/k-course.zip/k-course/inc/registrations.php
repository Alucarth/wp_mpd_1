<?php


add_action( 'init', 'k2t_course_register_ct', 0 );

function k2t_course_register_ct() {
	// Register course post type
	$slug = ( get_option( 'k2t_course_slug' ) != '' ) ?  get_option( 'k2t_course_slug' ) : esc_html__( 'k-course', 'k2t-course' );
	$slug_cat = ( get_option( 'k2t_course_category_slug' ) != '' ) ?  get_option( 'k2t_course_category_slug' ) : esc_html__( 'k-course-category', 'k2t-course' );
	$slug_tag = ( get_option( 'k2t_course_tag_slug' ) != '' ) ?  get_option( 'k2t_course_tag_slug' ) : esc_html__( 'k-course-tag', 'k2t-course' );

	$labels = array(
		'name'               => __('K-Course', 'k2t-course'),  
		'singular_name'      => __('K-Course', 'k2t-course'),  
		'add_new'            => __('Add New Course', 'k2t-course'),  
		'add_new_item'       => __('Add New Course', 'k2t-course'),  
		'edit_item'          => __('Edit Course', 'k2t-course'),  
		'new_item'           => __('New Course', 'k2t-course'),  
		'view_item'          => __('View Course', 'k2t-course'),  
		'all_items'          => __('All Courses', 'k2t-course'),
		'search_items'       => __('Search Course', 'k2t-course'),  
		'not_found'          => __('No Course found', 'k2t-course'),  
		'not_found_in_trash' => __('No Course found in Trash', 'k2t-course'),  
		'parent_item_colon'  => ''
	);
	$args = array (
		'labels'             => $labels,
        'description'        => __( 'Description.', 'k2t-course' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
		'rewrite' 			 => array( 'slug' => $slug, 'with_front' => FALSE )
	);

	register_post_type( 'post-k-course' , $args );

	// COURSE CATEGORY 

	$args = array(
		'labels' => array(
			'name'                => _x( 'Course Categories', 'taxonomy general name','k2t-course'),
			'singular_name'       => _x( 'K-Course Category', 'taxonomy singular name','k2t-course'),
			'search_items'        => __( 'Search K-Course Categories','k2t-course'),
			'all_items'           => __( 'All K-Course Categories','k2t-course'),
			'parent_item'         => __( 'Parent K-Course Category','k2t-course'),
			'parent_item_colon'   => __( 'Parent K-Course Category:','k2t-course'),
			'edit_item'           => __( 'Edit K-Course Category','k2t-course'), 
			'update_item'         => __( 'Update K-Course Category','k2t-course'),
			'add_new_item'        => __( 'Add New K-Course Category','k2t-course'),
			'new_item_name'       => __( 'New K-Course Category Name','k2t-course'),
			'menu_name'           => __( 'K-Course Categories','k2t-course')
		),
		'rewrite' => array('slug' => $slug_cat ),
	);

	register_taxonomy( 'k-course-category', 'post-k-course' , $args );

	// EVENT TAG

	$args = array(
		'labels' => array(
			'name'                => _x( 'K-Course Tags', 'taxonomy general name','k2t-course'),
			'singular_name'       => _x( 'K-Course Tag', 'taxonomy singular name','k2t-course'),
			'search_items'        => __( 'Search K-Course Tags','k2t-course'),
			'all_items'           => __( 'All K-Course Tags','k2t-course'),
			'parent_item'         => __( 'Parent K-Course Tag','k2t-course'),
			'parent_item_colon'   => __( 'Parent K-Course Tag:','k2t-course'),
			'edit_item'           => __( 'Edit K-Course Tag','k2t-course'), 
			'update_item'         => __( 'Update K-Course Tag','k2t-course'),
			'add_new_item'        => __( 'Add New K-Course Tag','k2t-course'),
			'new_item_name'       => __( 'New K-Course Tag Name','k2t-course'),
			'menu_name'           => __( 'K-Course Tags','k2t-course')
		),
		'rewrite' => array('slug' => $slug_tag ),
	);

	register_taxonomy( 'k-course-tag', 'post-k-course' , $args );
}
